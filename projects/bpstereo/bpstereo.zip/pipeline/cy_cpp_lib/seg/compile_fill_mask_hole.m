%compile_fill_mask_hole

mex cyFillMaskHole.cpp ...
    cy_mexbasic.cpp;